#!/bin/bash

# hack mali files around so we can test it

cp -aRP lib/* /usr/lib/aarch64-linux-gnu/
cp -aRP include/* /usr/include/
