[![Build Status](https://travis-ci.org/libretro/beetle-pce-fast-libretro.svg?branch=master)](https://travis-ci.org/libretro/beetle-pce-fast-libretro)
[![Build status](https://ci.appveyor.com/api/projects/status/6hii7ljchwjp80la/branch/master?svg=true)](https://ci.appveyor.com/project/bparker06/beetle-pce-fast-libretro/branch/master)

# Mednafen PC-Engine libretro
