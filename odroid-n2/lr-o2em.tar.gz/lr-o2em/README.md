libretro-o2em
==================

Port of O2EM to libretro.

Place "o2rom.bin" (required) in your RetroArch/libretro "System Directory" folder.