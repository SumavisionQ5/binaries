Original C-Dogs assets are licensed as CC-BY; see [./originals.txt](./originals.txt)

Unless otherwise specified, all artwork is licensed CC0 "Public Domain Dedication", copyright Cong Xu.
But please let me know if you like or use this artwork :)

https://creativecommons.org/publicdomain/zero/1.0/
