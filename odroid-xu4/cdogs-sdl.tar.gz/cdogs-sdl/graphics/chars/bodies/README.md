These are character sprites grouped by body types. The sprites are for the torso, arms and legs (no heads).

The sprites are generated from a blender source with animations.

To generate a body type, run:

    ./make_spritesheet.sh <body>

The sprites will be created inside the `<body>` folder.

> TODO: describe the blender file requirements, like animations, layers etc.