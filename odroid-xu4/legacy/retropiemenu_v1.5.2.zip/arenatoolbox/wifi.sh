#!/bin/bash
sudo nmtui
