#!/bin/bash
sudo systemctl restart getty@tty0 && sudo systemctl restart getty@tty1
