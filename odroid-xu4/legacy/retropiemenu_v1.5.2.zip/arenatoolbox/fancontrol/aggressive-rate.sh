sudo cp -r -f /home/pigaming/fan/aggressive/* /sys/devices/odroid_fan.14
sudo cp -r -f /home/pigaming/fan/aggressive/rc.local /etc
clear
echo Fan set to AGGRESSIVE cooling rates.
echo
echo Fan will become noticeably loud
echo
echo DISCLAIMER: PERFORM AT YOUR OWN RISK. NO IMPLIED WARRANTIES.
echo
echo Please wait a moment while configurations are set.
sleep 20

