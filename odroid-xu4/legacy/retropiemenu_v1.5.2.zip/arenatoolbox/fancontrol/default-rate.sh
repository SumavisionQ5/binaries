sudo cp -r -f /home/pigaming/fan/original/* /sys/devices/odroid_fan.14
sudo cp -r -f /home/pigaming/fan/original/rc.local /etc
clear
echo Fan set to DEFAULT rate values.
echo
echo Please wait a moment while configurations are set.
sleep 20
