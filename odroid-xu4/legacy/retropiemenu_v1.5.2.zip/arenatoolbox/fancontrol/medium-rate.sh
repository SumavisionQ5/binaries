sudo cp -r -f /home/pigaming/fan/cool-mode/* /sys/devices/odroid_fan.14
sudo cp -r -f /home/pigaming/fan/cool-mode/rc.local /etc
clear
echo Fan set to HIGHER COOLING RATE THAN DEFAULTS.
echo
echo DISCLAIMER: PERFORM AT YOUR OWN RISK. NO IMPLIED WARRANTIES.
echo
echo Please wait a moment while configurations are set.
sleep 20

