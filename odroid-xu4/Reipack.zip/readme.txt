------------------------------------------------------------
Reipack v0.2
------------------------------------------------------------

WHO
6alileo did this for all Retro-Arena users.

WHAT
It's a set of configuration files for the Libretro Reicast (lr-reicast) emulator and only works with Mame based roms.

Since the default Region is set to USA, the emulator will automatically load the USA BIOS. The opt files in "region" folder will override this setting with the Region set to Japan so that the Japan BIOS boots, thus letting the game load appropriately. In addition, vertical shooters are set to Vertical in Screen Orientation under Options menu.

The "roms_naomi" folder has most eeprom files with appropriate settings to Cabinet Type (# of Players) and Monitor Type set to Vertical for vertical shooter games.

The "roms_atomiswave" folder has most nvmem/nvmem2 files set to English language and volume set to 12 instead of 15 so it's not distorted. Most Atomiswave games are also set to Free Play if its configurable.

As a bonus, kofnw game will not load but if you use the included state file, you can load the save state via RetroArch RGUI or use SELECT+L1 to load it to bypass the freeze issue. The save state file is in "roms_atomiswave" folder.

The "ctrl_atomiswave" and "ctrl_naomi" folders include controller configurations for fightpads with 6 face buttons. It is tested with the Street Fighter vs. Tekken wired controller for the PS3. It should also work with other fightpads and even DualShock style controllers.

WHERE
Place the folders in this to the following:

ctrl_atomiswave = /opt/retropie/configs/atomiswave/Reicast
ctrl_naomi      = /opt/retropie/configs/naomi/Reicast
region          = /opt/retropie/configs/all/retroarch/config/Reicast
roms_atomiswave = /home/pigaming/RetroPie/roms/atomiswave
roms_naomi      = /home/pigaming/RetroPie/roms/naomi

WHY
For those with less time or just plain lazy or don't care.

------------------------------------------------------------
Release Log
------------------------------------------------------------
v0.1 - Initial release
v0.2 - Added reicast_synchronous_rendering = "enabled" to all opt files
     - Added controller config files